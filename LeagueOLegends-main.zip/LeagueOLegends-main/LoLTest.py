from Tkinter import *

top = Tkinter.Tk()

top.mainloop()
